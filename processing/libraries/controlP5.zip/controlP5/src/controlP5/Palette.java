package controlP5;

class Palette {

}
